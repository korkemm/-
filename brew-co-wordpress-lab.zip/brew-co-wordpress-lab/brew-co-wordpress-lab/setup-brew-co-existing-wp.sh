#!/usr/bin/env bash
set -euo pipefail

# Run this script from the root folder of an already installed WordPress site.
# Example:
#   cd /path/to/wordpress
#   bash /path/to/brew-co-wordpress-lab/setup-brew-co-existing-wp.sh
# Optional for Docker/root environments:
#   WP_EXTRA_ARGS="--allow-root" bash /path/to/setup-brew-co-existing-wp.sh

WP_BIN="${WP_BIN:-wp}"
WP_LANG="${WP_LANG:-en_US}"
WP_TIMEZONE="${WP_TIMEZONE:-Asia/Aqtau}"
ACTIVATE_CLASSIC_THEME="${ACTIVATE_CLASSIC_THEME:-1}"
THEME_SLUG="${THEME_SLUG:-twentytwentyone}"
PLUGIN_SLUG="${PLUGIN_SLUG:-contact-form-7}"

read -r -a WP_EXTRA_ARGS_ARRAY <<< "${WP_EXTRA_ARGS:-}"

wp_cmd() {
  "$WP_BIN" "${WP_EXTRA_ARGS_ARRAY[@]}" "$@"
}

if ! command -v "$WP_BIN" >/dev/null 2>&1; then
  echo "ERROR: WP-CLI was not found. Install WP-CLI first or use the manual checklist."
  exit 1
fi

if ! wp_cmd core is-installed >/dev/null 2>&1; then
  echo "ERROR: WordPress is not installed in this folder. Run this from the WordPress root folder."
  exit 1
fi

if [[ "$WP_LANG" != "en_US" ]]; then
  wp_cmd language core install "$WP_LANG" || true
  wp_cmd language core activate "$WP_LANG" || true
fi

if [[ "$ACTIVATE_CLASSIC_THEME" == "1" ]]; then
  if ! wp_cmd theme is-installed "$THEME_SLUG" >/dev/null 2>&1; then
    wp_cmd theme install "$THEME_SLUG"
  fi
  wp_cmd theme activate "$THEME_SLUG"
fi

if ! wp_cmd plugin is-installed "$PLUGIN_SLUG" >/dev/null 2>&1; then
  wp_cmd plugin install "$PLUGIN_SLUG"
fi
wp_cmd plugin activate "$PLUGIN_SLUG"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WP_LANG="$WP_LANG" WP_TIMEZONE="$WP_TIMEZONE" wp_cmd eval-file "$SCRIPT_DIR/brew-co-configure.php"

echo ""
echo "Done. Open the site front page and the WordPress Dashboard, then take the two screenshots required for submission."
