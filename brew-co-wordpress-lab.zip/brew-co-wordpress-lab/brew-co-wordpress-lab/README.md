# Brew & Co. WordPress Lab Package

This package completes the practical lab for the coffee shop website.

It creates/configures:

- Site title: `Brew & Co.`
- Tagline: `Coffee worth waking up for.`
- Timezone: `Asia/Aqtau` by default
- Language: `en_US` by default
- Pages: Home, About Us, Contact
- Blog post: Menu
- Category: Menu
- Primary Menu: Home, About Us, Menu, Contact
- Static front page: Home
- Text widget/footer content with address and hours
- Contact Form 7 plugin and form shortcode on the Contact page

## Option A - Existing WordPress site

1. Copy this folder to your computer/server.
2. Open a terminal in the WordPress root folder, the folder that contains `wp-config.php`.
3. Run:

```bash
bash /path/to/brew-co-wordpress-lab/setup-brew-co-existing-wp.sh
```

For Docker/root environments:

```bash
WP_EXTRA_ARGS="--allow-root" bash /path/to/brew-co-wordpress-lab/setup-brew-co-existing-wp.sh
```

By default the script activates the official classic theme `twentytwentyone` because it has clear menu and footer widget areas for grading. To keep the current theme:

```bash
ACTIVATE_CLASSIC_THEME=0 bash /path/to/brew-co-wordpress-lab/setup-brew-co-existing-wp.sh
```

## Option B - Fresh local install

Run this inside an empty web root folder. Edit variables as needed for XAMPP/MAMP/MySQL.

```bash
SITE_URL="http://localhost/brew-co" \
DB_NAME="brew_co" \
DB_USER="root" \
DB_PASS="" \
bash /path/to/brew-co-wordpress-lab/fresh-install-brew-co-local.sh
```

The default generated admin login is:

- Username: `admin`
- Password: `BrewCoStrongPass2026!`

Change this password before using the site for anything real.

## Option C - Manual setup

Use `manual-setup-checklist.md` if WP-CLI is not available.

## Final submission

Submit either:

- a live URL, or
- screenshots of the Dashboard and the front page.

The screenshot must be taken from the actual WordPress instance after the script/manual setup is complete.
