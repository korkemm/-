#!/usr/bin/env bash
set -euo pipefail

# Fresh local install helper. Run this in an empty web root folder.
# Edit variables below or pass them before the command, for example:
#   SITE_URL="http://localhost/brew-co" DB_NAME="brew_co" DB_USER="root" DB_PASS="" bash fresh-install-brew-co-local.sh

WP_BIN="${WP_BIN:-wp}"
SITE_URL="${SITE_URL:-http://localhost/brew-co}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-BrewCoStrongPass2026!}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
DB_NAME="${DB_NAME:-brew_co}"
DB_USER="${DB_USER:-root}"
DB_PASS="${DB_PASS:-}"
DB_HOST="${DB_HOST:-localhost}"
WP_LANG="${WP_LANG:-en_US}"
WP_TIMEZONE="${WP_TIMEZONE:-Asia/Aqtau}"

read -r -a WP_EXTRA_ARGS_ARRAY <<< "${WP_EXTRA_ARGS:-}"

wp_cmd() {
  "$WP_BIN" "${WP_EXTRA_ARGS_ARRAY[@]}" "$@"
}

if ! command -v "$WP_BIN" >/dev/null 2>&1; then
  echo "ERROR: WP-CLI was not found. Install WP-CLI first or use the manual checklist."
  exit 1
fi

if [[ ! -f wp-load.php ]]; then
  wp_cmd core download --locale="$WP_LANG"
fi

if command -v mysql >/dev/null 2>&1; then
  MYSQL_ARGS=(-h "$DB_HOST" -u "$DB_USER")
  if [[ -n "$DB_PASS" ]]; then
    MYSQL_ARGS+=("-p$DB_PASS")
  fi
  mysql "${MYSQL_ARGS[@]}" -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || true
fi

if [[ ! -f wp-config.php ]]; then
  wp_cmd config create --dbname="$DB_NAME" --dbuser="$DB_USER" --dbpass="$DB_PASS" --dbhost="$DB_HOST" --skip-check
fi

if ! wp_cmd core is-installed >/dev/null 2>&1; then
  wp_cmd core install \
    --url="$SITE_URL" \
    --title="Brew & Co." \
    --admin_user="$ADMIN_USER" \
    --admin_password="$ADMIN_PASSWORD" \
    --admin_email="$ADMIN_EMAIL" \
    --skip-email
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WP_LANG="$WP_LANG" WP_TIMEZONE="$WP_TIMEZONE" bash "$SCRIPT_DIR/setup-brew-co-existing-wp.sh"

echo ""
echo "Admin URL: $SITE_URL/wp-admin/"
echo "Username: $ADMIN_USER"
echo "Password: $ADMIN_PASSWORD"
echo "Change the password before using this site for anything real."
