<?php
/**
 * Brew & Co. WordPress lab configurator.
 * Run with: wp eval-file brew-co-configure.php
 */

if (!defined('ABSPATH')) {
    fwrite(STDERR, "This file must be run inside WordPress with WP-CLI.\n");
    exit(1);
}

function brew_log($message) {
    if (class_exists('WP_CLI')) {
        WP_CLI::log($message);
    } else {
        echo $message . PHP_EOL;
    }
}

function brew_success($message) {
    if (class_exists('WP_CLI')) {
        WP_CLI::success($message);
    } else {
        echo "SUCCESS: " . $message . PHP_EOL;
    }
}

function brew_error($message) {
    if (class_exists('WP_CLI')) {
        WP_CLI::error($message);
    }
    fwrite(STDERR, "ERROR: " . $message . PHP_EOL);
    exit(1);
}

function brew_upsert_content($post_type, $slug, $title, $content) {
    $existing = get_page_by_path($slug, OBJECT, $post_type);

    $post_data = array(
        'post_type'    => $post_type,
        'post_name'    => $slug,
        'post_title'   => $title,
        'post_content' => $content,
        'post_status'  => 'publish',
    );

    if ($existing) {
        $post_data['ID'] = $existing->ID;
        $result = wp_update_post($post_data, true);
    } else {
        $result = wp_insert_post($post_data, true);
    }

    if (is_wp_error($result)) {
        brew_error('Could not create or update ' . $title . ': ' . $result->get_error_message());
    }

    return (int) $result;
}

function brew_find_cf7_form($title) {
    if (!class_exists('WPCF7_ContactForm')) {
        return null;
    }

    $posts = get_posts(array(
        'post_type'      => 'wpcf7_contact_form',
        'post_status'    => 'any',
        'posts_per_page' => -1,
    ));

    foreach ($posts as $post) {
        if ($post->post_title === $title) {
            return WPCF7_ContactForm::get_instance($post->ID);
        }
    }

    return null;
}

function brew_prepare_cf7_shortcode() {
    if (!class_exists('WPCF7_ContactForm')) {
        return '<p><strong>Contact Form 7 is not active.</strong> Activate Contact Form 7 and run the setup again.</p>';
    }

    $form_title = 'Brew & Co Contact Form';
    $form = brew_find_cf7_form($form_title);

    if (!$form) {
        $form = WPCF7_ContactForm::get_template(array('title' => $form_title));
    }

    if (!$form) {
        return '<p><strong>Contact form could not be created.</strong></p>';
    }

    $form_markup = <<<'CF7'
<label> Your name
    [text* your-name autocomplete:name]
</label>

<label> Your email
    [email* your-email autocomplete:email]
</label>

<label> Subject
    [text* your-subject]
</label>

<label> Your message
    [textarea* your-message]
</label>

[submit "Send"]
CF7;

    $mail = $form->prop('mail');
    if (!is_array($mail)) {
        $mail = array();
    }

    $mail['active'] = true;
    $mail['recipient'] = get_option('admin_email');
    $mail['sender'] = '[your-name] <[your-email]>';
    $mail['subject'] = 'Brew & Co contact: [your-subject]';
    $mail['body'] = "From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis email was sent from the Brew & Co. website.";
    $mail['additional_headers'] = 'Reply-To: [your-email]';
    $mail['attachments'] = '';
    $mail['use_html'] = false;
    $mail['exclude_blank'] = false;

    $form->set_properties(array(
        'form' => $form_markup,
        'mail' => $mail,
    ));

    $form->save();
    $form_id = (int) $form->id();

    return '[contact-form-7 id="' . $form_id . '" title="' . esc_attr($form_title) . '"]';
}

function brew_setup_classic_menu($home_id, $about_id, $menu_post_id, $contact_id) {
    $menu_name = 'Primary Menu';
    $menu_obj = wp_get_nav_menu_object($menu_name);
    $menu_id = $menu_obj ? (int) $menu_obj->term_id : 0;

    if (!$menu_id) {
        $created = wp_create_nav_menu($menu_name);
        if (is_wp_error($created)) {
            brew_log('Classic menu could not be created: ' . $created->get_error_message());
            return 0;
        }
        $menu_id = (int) $created;
    }

    $items = wp_get_nav_menu_items($menu_id);
    if ($items) {
        foreach ($items as $item) {
            wp_delete_post($item->ID, true);
        }
    }

    $menu_items = array(
        array('title' => 'Home', 'type' => 'post_type', 'object' => 'page', 'object_id' => $home_id),
        array('title' => 'About Us', 'type' => 'post_type', 'object' => 'page', 'object_id' => $about_id),
        array('title' => 'Menu', 'type' => 'post_type', 'object' => 'post', 'object_id' => $menu_post_id),
        array('title' => 'Contact', 'type' => 'post_type', 'object' => 'page', 'object_id' => $contact_id),
    );

    foreach ($menu_items as $item) {
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title'     => $item['title'],
            'menu-item-type'      => $item['type'],
            'menu-item-object'    => $item['object'],
            'menu-item-object-id' => $item['object_id'],
            'menu-item-status'    => 'publish',
        ));
    }

    $registered_locations = get_registered_nav_menus();
    if (!empty($registered_locations)) {
        $location = array_key_exists('primary', $registered_locations) ? 'primary' : key($registered_locations);
        $theme_locations = get_theme_mod('nav_menu_locations');
        if (!is_array($theme_locations)) {
            $theme_locations = array();
        }
        $theme_locations[$location] = $menu_id;
        set_theme_mod('nav_menu_locations', $theme_locations);
        brew_log('Assigned classic menu to theme location: ' . $location);
    } else {
        brew_log('No classic menu locations found in the active theme. A block navigation menu was also created.');
    }

    return $menu_id;
}

function brew_nav_link_block($label, $url, $kind = 'custom', $type = 'custom', $id = 0) {
    $attrs = array(
        'label' => $label,
        'url'   => $url,
        'kind'  => $kind,
        'type'  => $type,
    );
    if ($id) {
        $attrs['id'] = (int) $id;
    }

    return '<!-- wp:navigation-link ' . wp_json_encode($attrs, JSON_UNESCAPED_SLASHES) . ' /-->';
}

function brew_setup_block_navigation($home_id, $about_id, $menu_post_id, $contact_id) {
    if (!post_type_exists('wp_navigation')) {
        return;
    }

    $nav_content = implode("\n", array(
        brew_nav_link_block('Home', get_permalink($home_id), 'post-type', 'page', $home_id),
        brew_nav_link_block('About Us', get_permalink($about_id), 'post-type', 'page', $about_id),
        brew_nav_link_block('Menu', get_permalink($menu_post_id), 'post-type', 'post', $menu_post_id),
        brew_nav_link_block('Contact', get_permalink($contact_id), 'post-type', 'page', $contact_id),
    ));

    $nav_posts = get_posts(array(
        'post_type'      => 'wp_navigation',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
    ));

    if (empty($nav_posts)) {
        wp_insert_post(array(
            'post_type'    => 'wp_navigation',
            'post_status'  => 'publish',
            'post_title'   => 'Primary Menu',
            'post_name'    => 'primary-menu',
            'post_content' => $nav_content,
        ));
        brew_log('Created block theme navigation: Primary Menu');
        return;
    }

    foreach ($nav_posts as $nav_post) {
        wp_update_post(array(
            'ID'           => $nav_post->ID,
            'post_title'   => 'Primary Menu',
            'post_content' => $nav_content,
        ));
    }
    brew_log('Updated block theme navigation posts.');
}

function brew_setup_text_widget() {
    $widget_title = 'Visit Brew & Co.';
    $widget_text = '<p><strong>Address:</strong> 123 Bean Street, Coffeeville</p><p><strong>Hours:</strong> Monday-Saturday, 7:00 AM-6:00 PM</p><p><strong>Phone:</strong> (555) 012-2024</p>';

    global $wp_registered_sidebars;

    $sidebars = wp_get_sidebars_widgets();
    if (!is_array($sidebars)) {
        $sidebars = array();
    }

    $preferred = array('sidebar-1', 'footer-1', 'footer', 'footer-sidebar', 'footer-widgets');
    $target = '';

    foreach ($preferred as $candidate) {
        if (isset($sidebars[$candidate]) || isset($wp_registered_sidebars[$candidate])) {
            $target = $candidate;
            break;
        }
    }

    if (!$target && !empty($wp_registered_sidebars)) {
        $keys = array_keys($wp_registered_sidebars);
        $target = $keys[0];
    }

    if (!$target) {
        brew_log('No widget area found in the active theme. The address and hours are also included on the Contact page.');
        return;
    }

    $text_widgets = get_option('widget_text');
    if (!is_array($text_widgets)) {
        $text_widgets = array();
    }

    $widget_id = '';
    foreach ($text_widgets as $number => $settings) {
        if (is_array($settings) && isset($settings['title']) && $settings['title'] === $widget_title) {
            $text_widgets[$number] = array(
                'title'  => $widget_title,
                'text'   => $widget_text,
                'filter' => true,
                'visual' => true,
            );
            $widget_id = 'text-' . $number;
            break;
        }
    }

    if (!$widget_id) {
        $new_number = 2;
        foreach (array_keys($text_widgets) as $key) {
            if (is_numeric($key)) {
                $new_number = max($new_number, ((int) $key) + 1);
            }
        }

        $text_widgets[$new_number] = array(
            'title'  => $widget_title,
            'text'   => $widget_text,
            'filter' => true,
            'visual' => true,
        );
        $widget_id = 'text-' . $new_number;
    }

    $text_widgets['_multiwidget'] = 1;
    update_option('widget_text', $text_widgets);

    foreach ($sidebars as $sidebar_id => $widgets) {
        if (is_array($widgets)) {
            $sidebars[$sidebar_id] = array_values(array_diff($widgets, array($widget_id)));
        }
    }

    if (!isset($sidebars[$target]) || !is_array($sidebars[$target])) {
        $sidebars[$target] = array();
    }
    $sidebars[$target][] = $widget_id;
    wp_set_sidebars_widgets($sidebars);

    brew_log('Added text widget to widget area: ' . $target);
}

update_option('blogname', 'Brew & Co.');
update_option('blogdescription', 'Coffee worth waking up for.');
update_option('timezone_string', getenv('WP_TIMEZONE') ? getenv('WP_TIMEZONE') : 'Asia/Aqtau');
update_option('WPLANG', getenv('WP_LANG') ? getenv('WP_LANG') : 'en_US');

$form_shortcode = brew_prepare_cf7_shortcode();

$home_content = <<<'HTML'
<h2>Welcome to Brew &amp; Co.</h2>
<p>Brew &amp; Co. is a cozy local coffee shop serving fresh espresso, hand-crafted drinks, and baked treats every morning. Whether you need a quiet place to study or a quick cup before work, our team is ready to make your day warmer.</p>
<p>Visit us for smooth coffee, friendly service, and seasonal specials made with care.</p>
HTML;

$about_content = <<<'HTML'
<h2>About Brew &amp; Co.</h2>
<p>Brew &amp; Co. started as a neighborhood coffee bar with a simple goal: make great coffee feel welcoming to everyone. We source quality beans, train our baristas carefully, and prepare each drink with attention to flavor.</p>
<p>Our shop is a comfortable place for students, workers, families, and friends to gather, relax, and enjoy a fresh cup.</p>
HTML;

$contact_content = <<<'HTML'
<h2>Contact Brew &amp; Co.</h2>
<p>Have a question about our menu, catering, or opening hours? Send us a message and a team member will get back to you soon.</p>
<p>You can also visit us at 123 Bean Street, Coffeeville, Monday-Saturday from 7:00 AM to 6:00 PM.</p>

HTML;
$contact_content .= "\n" . $form_shortcode . "\n";

$menu_content = <<<'HTML'
<h2>Our Coffee Menu</h2>
<p>Explore some of Brew &amp; Co.'s customer favorites. Prices are simple, and most drinks can be made hot or iced.</p>

<h3>Espresso - $3.00</h3>
<p>A rich, concentrated shot of coffee with a bold flavor and smooth finish.</p>

<h3>Cappuccino - $4.25</h3>
<p>Classic espresso topped with steamed milk and a soft layer of foam.</p>

<h3>Vanilla Latte - $4.75</h3>
<p>Espresso blended with steamed milk and a gentle vanilla sweetness.</p>

<h3>Mocha - $5.00</h3>
<p>A warm mix of espresso, chocolate, and milk for a sweet coffee treat.</p>

<h3>Blueberry Muffin - $3.50</h3>
<p>A fresh bakery favorite that pairs perfectly with any morning drink.</p>
HTML;

$home_id = brew_upsert_content('page', 'home', 'Home', $home_content);
$about_id = brew_upsert_content('page', 'about-us', 'About Us', $about_content);
$contact_id = brew_upsert_content('page', 'contact', 'Contact', $contact_content);
$menu_post_id = brew_upsert_content('post', 'menu', 'Menu', $menu_content);

$term = term_exists('Menu', 'category');
if (!$term) {
    $term = wp_insert_term('Menu', 'category');
}
if (is_wp_error($term)) {
    brew_error('Could not create Menu category: ' . $term->get_error_message());
}
$menu_category_id = is_array($term) ? (int) $term['term_id'] : (int) $term;
wp_set_post_terms($menu_post_id, array($menu_category_id), 'category', false);

update_option('show_on_front', 'page');
update_option('page_on_front', $home_id);
update_option('page_for_posts', 0);

brew_setup_classic_menu($home_id, $about_id, $menu_post_id, $contact_id);
brew_setup_block_navigation($home_id, $about_id, $menu_post_id, $contact_id);
brew_setup_text_widget();

update_option('permalink_structure', '/%postname%/');
flush_rewrite_rules();

brew_log('Front page: ' . get_permalink($home_id));
brew_log('Menu post: ' . get_permalink($menu_post_id));
brew_log('Contact page: ' . get_permalink($contact_id));
brew_success('Brew & Co. WordPress lab site configured.');
