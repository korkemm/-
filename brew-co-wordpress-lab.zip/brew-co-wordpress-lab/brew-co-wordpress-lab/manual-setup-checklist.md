# Brew & Co. WordPress Lab - Manual Setup Checklist

Use this if WP-CLI is not available.

## 1. Settings

Dashboard > Settings > General:

- Site Title: `Brew & Co.`
- Tagline: `Coffee worth waking up for.`
- Site Language: `English (United States)`
- Timezone: `Asia/Aqtau` or your local timezone

## 2. Pages

Create these pages in Dashboard > Pages > Add New.

### Home

```html
<h2>Welcome to Brew &amp; Co.</h2>
<p>Brew &amp; Co. is a cozy local coffee shop serving fresh espresso, hand-crafted drinks, and baked treats every morning. Whether you need a quiet place to study or a quick cup before work, our team is ready to make your day warmer.</p>
<p>Visit us for smooth coffee, friendly service, and seasonal specials made with care.</p>
```

### About Us

```html
<h2>About Brew &amp; Co.</h2>
<p>Brew &amp; Co. started as a neighborhood coffee bar with a simple goal: make great coffee feel welcoming to everyone. We source quality beans, train our baristas carefully, and prepare each drink with attention to flavor.</p>
<p>Our shop is a comfortable place for students, workers, families, and friends to gather, relax, and enjoy a fresh cup.</p>
```

### Contact

Install Contact Form 7 first, then paste the shortcode from the created form below the text.

```html
<h2>Contact Brew &amp; Co.</h2>
<p>Have a question about our menu, catering, or opening hours? Send us a message and a team member will get back to you soon.</p>
<p>You can also visit us at 123 Bean Street, Coffeeville, Monday-Saturday from 7:00 AM to 6:00 PM.</p>

[contact-form-7 id="FORM_ID" title="Contact form 1"]
```

## 3. Menu blog post

Dashboard > Posts > Add New:

- Title: `Menu`
- Category: `Menu`

```html
<h2>Our Coffee Menu</h2>
<p>Explore some of Brew &amp; Co.'s customer favorites. Prices are simple, and most drinks can be made hot or iced.</p>

<h3>Espresso - $3.00</h3>
<p>A rich, concentrated shot of coffee with a bold flavor and smooth finish.</p>

<h3>Cappuccino - $4.25</h3>
<p>Classic espresso topped with steamed milk and a soft layer of foam.</p>

<h3>Vanilla Latte - $4.75</h3>
<p>Espresso blended with steamed milk and a gentle vanilla sweetness.</p>

<h3>Mocha - $5.00</h3>
<p>A warm mix of espresso, chocolate, and milk for a sweet coffee treat.</p>

<h3>Blueberry Muffin - $3.50</h3>
<p>A fresh bakery favorite that pairs perfectly with any morning drink.</p>
```

## 4. Navigation menu

Dashboard > Appearance > Menus or Appearance > Editor > Navigation:

Create `Primary Menu` and add links in this order:

1. Home
2. About Us
3. Menu
4. Contact

## 5. Static front page

Dashboard > Settings > Reading:

- Select `A static page`
- Homepage: `Home`

## 6. Widget or footer block

Dashboard > Appearance > Widgets, or Appearance > Editor > Footer:

Add a Text widget/block:

```html
<p><strong>Address:</strong> 123 Bean Street, Coffeeville</p>
<p><strong>Hours:</strong> Monday-Saturday, 7:00 AM-6:00 PM</p>
<p><strong>Phone:</strong> (555) 012-2024</p>
```

## 7. Plugin and form

Dashboard > Plugins > Add New:

- Search for `Contact Form 7`
- Install and activate it
- Copy the form shortcode
- Paste it at the bottom of the Contact page

## Submission screenshots

Take these screenshots after setup:

1. WordPress Dashboard showing Pages/Posts or Settings.
2. Front page showing the Brew & Co. homepage and navigation.
